# Tea Trade & Supply Chain Analysis

## Descripción
Proyecto de análisis de exportaciones e importaciones de té a nivel mundial, con enfoque en volúmenes, valores y tarifas. Incluye integración de datos en SQL y visualización con Power BI.

## Objetivos
- Analizar volúmenes y valores de exportación por país y tipo de té.
- Identificar tendencias y correlaciones con tarifas o costos logísticos.
- Construir dashboard interactivo en Power BI.

## Estructura del proyecto
```
tea-trade-project/
├── data/                    # Archivos CSV con datos de exportaciones, valores y tarifas
├── sql/                     # Scripts SQL para limpieza, transformación y análisis
├── powerbi/                 # Archivo PBIX con dashboard
├── outputs/                 # Resultados y capturas de pantalla
└── README.md                # Documentación principal
```

## Herramientas
- SQL Server / PostgreSQL
- Power BI
- Python o Excel (opcional para limpieza previa)

## Flujo de trabajo
1. Cargar y limpiar datos en SQL.
2. Realizar uniones y cálculos clave (precio promedio, evolución, etc.).
3. Exportar resultados a Power BI.
4. Diseñar dashboard interactivo con filtros por país, año y tipo de té.

## Próximos pasos
- Agregar datasets reales de exportaciones de té (FAO, Trendeconomy, UN Comtrade).
- Construir consultas SQL base.
- Diseñar primer prototipo de dashboard.
